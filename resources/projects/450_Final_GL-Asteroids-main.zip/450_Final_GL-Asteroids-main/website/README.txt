Name: Octavio Almanza

Name of Project: GL-Asteroids

All of the website files are inside the website directory.

I have included a 200x200 thumbnail.gif file.