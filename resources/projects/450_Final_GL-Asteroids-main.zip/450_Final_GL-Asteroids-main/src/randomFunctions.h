#pragma once

float randomFloat(float a, float b);